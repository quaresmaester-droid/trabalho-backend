
DROP INDEX idx_content_blocks_order;
DROP INDEX idx_content_blocks_chapter_id;
DROP TABLE content_blocks;

DROP INDEX idx_chapters_chapter_number;
DROP INDEX idx_chapters_book_id;
DROP TABLE chapters;

DROP INDEX idx_books_created_at;
DROP INDEX idx_books_is_published;
DROP INDEX idx_books_user_id;
DROP TABLE books;
