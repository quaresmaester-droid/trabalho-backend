import { BrowserRouter as Router, Routes, Route } from "react-router";
import { AuthProvider } from "@getmocha/users-service/react";
import HomePage from "@/react-app/pages/Home";
import AuthCallbackPage from "@/react-app/pages/AuthCallback";
import BookDetailPage from "@/react-app/pages/BookDetail";
import ReadChapterPage from "@/react-app/pages/ReadChapter";
import MyBooksPage from "@/react-app/pages/MyBooks";
import CreateBookPage from "@/react-app/pages/CreateBook";
import EditBookPage from "@/react-app/pages/EditBook";
import CreateChapterPage from "@/react-app/pages/CreateChapter";
import EditChapterPage from "@/react-app/pages/EditChapter";

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/auth/callback" element={<AuthCallbackPage />} />
          <Route path="/books/:id" element={<BookDetailPage />} />
          <Route path="/books/:bookId/chapters/:chapterId" element={<ReadChapterPage />} />
          <Route path="/my-books" element={<MyBooksPage />} />
          <Route path="/create-book" element={<CreateBookPage />} />
          <Route path="/books/:id/edit" element={<EditBookPage />} />
          <Route path="/books/:bookId/create-chapter" element={<CreateChapterPage />} />
          <Route path="/chapters/:id/edit" element={<EditChapterPage />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}
