import { Link } from "react-router";
import { Book } from "@/shared/types";
import { Eye } from "lucide-react";

interface BookCardProps {
  book: Book;
}

export default function BookCard({ book }: BookCardProps) {
  return (
    <Link
      to={`/books/${book.id}`}
      className="group block bg-white rounded-xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1"
    >
      <div className="aspect-[3/4] bg-gradient-to-br from-purple-400 to-pink-400 relative overflow-hidden">
        {book.cover_image_url ? (
          <img
            src={book.cover_image_url}
            alt={book.title}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-white text-6xl font-bold opacity-30">
              {book.title.charAt(0).toUpperCase()}
            </span>
          </div>
        )}
      </div>

      <div className="p-4">
        <h3 className="font-bold text-lg text-gray-900 group-hover:text-purple-600 transition-colors line-clamp-2 mb-2">
          {book.title}
        </h3>

        {book.description && (
          <p className="text-sm text-gray-600 line-clamp-2 mb-3">
            {book.description}
          </p>
        )}

        <div className="flex items-center justify-between text-xs text-gray-500">
          {book.genre && (
            <span className="px-2 py-1 bg-purple-100 text-purple-700 rounded-full">
              {book.genre}
            </span>
          )}
          <div className="flex items-center space-x-1">
            <Eye className="w-4 h-4" />
            <span>{book.view_count}</span>
          </div>
        </div>
      </div>
    </Link>
  );
}
