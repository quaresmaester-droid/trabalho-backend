import { useState } from "react";
import { ContentBlock } from "@/shared/types";
import {
  Plus,
  Trash2,
  Upload,
  Save,
  Loader2,
  MoveUp,
  MoveDown,
} from "lucide-react";

interface ContentBlockEditorProps {
  chapterId: number;
  blocks: ContentBlock[];
  onBlocksUpdate: (blocks: ContentBlock[]) => void;
}

export default function ContentBlockEditor({
  chapterId,
  blocks,
  onBlocksUpdate,
}: ContentBlockEditorProps) {
  const [editingBlocks, setEditingBlocks] = useState<{
    [key: number]: {
      text_content: string;
      media_type?: string;
      media_url?: string;
      media_source?: string;
    };
  }>({});
  const [uploading, setUploading] = useState(false);

  const addNewBlock = async () => {
    const newOrder = blocks.length;

    try {
      const res = await fetch("/api/content-blocks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chapter_id: chapterId,
          block_order: newOrder,
          text_content: "",
        }),
      });

      if (res.ok) {
        const newBlock = await res.json();
        onBlocksUpdate([...blocks, newBlock]);
      }
    } catch (error) {
      console.error("Failed to create block:", error);
    }
  };

  const updateBlock = async (blockId: number) => {
    const updates = editingBlocks[blockId];
    if (!updates) return;

    try {
      const res = await fetch(`/api/content-blocks/${blockId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });

      if (res.ok) {
        const updated = await res.json();
        onBlocksUpdate(blocks.map((b) => (b.id === blockId ? updated : b)));
        setEditingBlocks((prev) => {
          const newState = { ...prev };
          delete newState[blockId];
          return newState;
        });
      }
    } catch (error) {
      console.error("Failed to update block:", error);
    }
  };

  const deleteBlock = async (blockId: number) => {
    if (!confirm("Tem certeza que deseja excluir este bloco?")) return;

    try {
      const res = await fetch(`/api/content-blocks/${blockId}`, {
        method: "DELETE",
      });

      if (res.ok) {
        onBlocksUpdate(blocks.filter((b) => b.id !== blockId));
      }
    } catch (error) {
      console.error("Failed to delete block:", error);
    }
  };

  const moveBlock = async (blockId: number, direction: "up" | "down") => {
    const currentIndex = blocks.findIndex((b) => b.id === blockId);
    if (currentIndex === -1) return;
    if (direction === "up" && currentIndex === 0) return;
    if (direction === "down" && currentIndex === blocks.length - 1) return;

    const newIndex = direction === "up" ? currentIndex - 1 : currentIndex + 1;
    const newBlocks = [...blocks];
    [newBlocks[currentIndex], newBlocks[newIndex]] = [
      newBlocks[newIndex],
      newBlocks[currentIndex],
    ];

    // Update order for both blocks
    try {
      await Promise.all([
        fetch(`/api/content-blocks/${newBlocks[currentIndex].id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ block_order: currentIndex }),
        }),
        fetch(`/api/content-blocks/${newBlocks[newIndex].id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ block_order: newIndex }),
        }),
      ]);

      onBlocksUpdate(newBlocks);
    } catch (error) {
      console.error("Failed to reorder blocks:", error);
    }
  };

  const handleFileUpload = async (blockId: number, file: File) => {
    setUploading(true);

    try {
      const formData = new FormData();
      formData.append("file", file);

      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      if (res.ok) {
        const { url } = await res.json();
        const mediaType = file.type.startsWith("image/")
          ? "image"
          : file.type.startsWith("video/")
          ? "video"
          : "audio";

        setEditingBlocks((prev) => ({
          ...prev,
          [blockId]: {
            ...prev[blockId],
            text_content: prev[blockId]?.text_content || "",
            media_type: mediaType,
            media_url: url,
            media_source: "upload",
          },
        }));
      }
    } catch (error) {
      console.error("Failed to upload file:", error);
    } finally {
      setUploading(false);
    }
  };

  const getBlockValue = (blockId: number, field: keyof ContentBlock) => {
    const block = blocks.find((b) => b.id === blockId);
    if (editingBlocks[blockId]?.[field as keyof typeof editingBlocks[number]]) {
      return editingBlocks[blockId][field as keyof typeof editingBlocks[number]];
    }
    return block?.[field] || "";
  };

  const hasUnsavedChanges = (blockId: number) => {
    return !!editingBlocks[blockId];
  };

  return (
    <div className="space-y-6">
      {blocks.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
          <p className="text-gray-500 mb-4">
            Nenhum bloco de conteúdo ainda. Adicione o primeiro!
          </p>
          <button
            onClick={addNewBlock}
            className="inline-flex items-center space-x-2 px-4 py-2 gradient-primary text-white rounded-lg font-medium hover:opacity-90 transition-opacity"
          >
            <Plus className="w-4 h-4" />
            <span>Adicionar Primeiro Bloco</span>
          </button>
        </div>
      ) : (
        <>
          {blocks.map((block, index) => (
            <div
              key={block.id}
              className="border-2 border-gray-200 rounded-lg p-6 space-y-4 hover:border-purple-300 transition-colors"
            >
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm font-medium text-gray-500">
                  Bloco {index + 1}
                </span>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => moveBlock(block.id, "up")}
                    disabled={index === 0}
                    className="p-1 hover:bg-gray-100 rounded disabled:opacity-30"
                    title="Mover para cima"
                  >
                    <MoveUp className="w-4 h-4 text-gray-600" />
                  </button>
                  <button
                    onClick={() => moveBlock(block.id, "down")}
                    disabled={index === blocks.length - 1}
                    className="p-1 hover:bg-gray-100 rounded disabled:opacity-30"
                    title="Mover para baixo"
                  >
                    <MoveDown className="w-4 h-4 text-gray-600" />
                  </button>
                  <button
                    onClick={() => deleteBlock(block.id)}
                    className="p-1 hover:bg-red-100 rounded"
                    title="Excluir bloco"
                  >
                    <Trash2 className="w-4 h-4 text-red-600" />
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Texto do Parágrafo
                </label>
                <textarea
                  value={getBlockValue(block.id, "text_content") as string}
                  onChange={(e) =>
                    setEditingBlocks((prev) => ({
                      ...prev,
                      [block.id]: {
                        ...prev[block.id],
                        text_content: e.target.value,
                      },
                    }))
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
                  rows={4}
                  placeholder="Digite o texto do parágrafo aqui..."
                />
              </div>

              <div className="border-t pt-4">
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Mídia (opcional - apenas uma por bloco)
                </label>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-gray-600 mb-1">
                      Tipo de Mídia
                    </label>
                    <select
                      value={getBlockValue(block.id, "media_type") as string}
                      onChange={(e) =>
                        setEditingBlocks((prev) => ({
                          ...prev,
                          [block.id]: {
                            ...prev[block.id],
                            text_content:
                              prev[block.id]?.text_content ||
                              (block.text_content as string) ||
                              "",
                            media_type: e.target.value || undefined,
                          },
                        }))
                      }
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm"
                    >
                      <option value="">Nenhuma</option>
                      <option value="image">Imagem</option>
                      <option value="gif">GIF</option>
                      <option value="video">Vídeo</option>
                      <option value="audio">Áudio</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs text-gray-600 mb-1">Origem</label>
                    <select
                      value={getBlockValue(block.id, "media_source") as string}
                      onChange={(e) =>
                        setEditingBlocks((prev) => ({
                          ...prev,
                          [block.id]: {
                            ...prev[block.id],
                            text_content:
                              prev[block.id]?.text_content ||
                              (block.text_content as string) ||
                              "",
                            media_source: e.target.value || undefined,
                          },
                        }))
                      }
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm"
                      disabled={!getBlockValue(block.id, "media_type")}
                    >
                      <option value="">Selecione</option>
                      <option value="youtube">YouTube</option>
                      <option value="dailymotion">Dailymotion</option>
                      <option value="drive">Google Drive</option>
                      <option value="upload">Upload Local</option>
                    </select>
                  </div>
                </div>

                {getBlockValue(block.id, "media_type") &&
                  getBlockValue(block.id, "media_source") === "upload" && (
                    <div className="mt-3">
                      <label className="block text-xs text-gray-600 mb-1">
                        Upload de Arquivo
                      </label>
                      <div className="flex items-center space-x-2">
                        <label className="flex-1 cursor-pointer">
                          <div className="flex items-center space-x-2 px-4 py-2 border-2 border-dashed border-gray-300 rounded-lg hover:border-purple-400 transition-colors">
                            <Upload className="w-4 h-4 text-gray-500" />
                            <span className="text-sm text-gray-600">
                              Selecionar arquivo
                            </span>
                          </div>
                          <input
                            type="file"
                            className="hidden"
                            accept={
                              getBlockValue(block.id, "media_type") === "image"
                                ? "image/*"
                                : getBlockValue(block.id, "media_type") === "video"
                                ? "video/*"
                                : "audio/*"
                            }
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) handleFileUpload(block.id, file);
                            }}
                            disabled={uploading}
                          />
                        </label>
                        {uploading && <Loader2 className="w-5 h-5 animate-spin" />}
                      </div>
                    </div>
                  )}

                {getBlockValue(block.id, "media_type") &&
                  getBlockValue(block.id, "media_source") &&
                  getBlockValue(block.id, "media_source") !== "upload" && (
                    <div className="mt-3">
                      <label className="block text-xs text-gray-600 mb-1">
                        URL da Mídia Externa
                      </label>
                      <input
                        type="url"
                        value={getBlockValue(block.id, "media_url") as string}
                        onChange={(e) =>
                          setEditingBlocks((prev) => ({
                            ...prev,
                            [block.id]: {
                              ...prev[block.id],
                              text_content:
                                prev[block.id]?.text_content ||
                                (block.text_content as string) ||
                                "",
                              media_url: e.target.value,
                            },
                          }))
                        }
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm"
                        placeholder="https://..."
                      />
                    </div>
                  )}
              </div>

              {hasUnsavedChanges(block.id) && (
                <button
                  onClick={() => updateBlock(block.id)}
                  className="w-full flex items-center justify-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
                >
                  <Save className="w-4 h-4" />
                  <span>Salvar Bloco</span>
                </button>
              )}
            </div>
          ))}

          <button
            onClick={addNewBlock}
            className="w-full flex items-center justify-center space-x-2 px-4 py-3 border-2 border-dashed border-purple-300 text-purple-600 rounded-lg hover:bg-purple-50 transition-colors font-medium"
          >
            <Plus className="w-5 h-5" />
            <span>Adicionar Novo Bloco</span>
          </button>
        </>
      )}
    </div>
  );
}
