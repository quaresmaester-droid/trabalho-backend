import { Link } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import { BookOpen, LogOut, PenTool, User } from "lucide-react";

export default function Navbar() {
  const { user, redirectToLogin, logout } = useAuth();

  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-lg border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <BookOpen className="w-8 h-8 text-purple-600" />
            <span className="text-2xl font-bold gradient-primary text-gradient">
              StoryVerse
            </span>
          </Link>

          <div className="flex items-center space-x-6">
            <Link
              to="/"
              className="text-gray-700 hover:text-purple-600 transition-colors font-medium"
            >
              Explorar
            </Link>

            {user ? (
              <>
                <Link
                  to="/my-books"
                  className="flex items-center space-x-2 text-gray-700 hover:text-purple-600 transition-colors font-medium"
                >
                  <PenTool className="w-4 h-4" />
                  <span>Meus Livros</span>
                </Link>

                <div className="flex items-center space-x-3">
                  <div className="flex items-center space-x-2 px-3 py-2 rounded-full bg-purple-50">
                    <User className="w-4 h-4 text-purple-600" />
                    <span className="text-sm font-medium text-purple-900">
                      {user.google_user_data.given_name || user.email}
                    </span>
                  </div>
                  <button
                    onClick={() => logout()}
                    className="p-2 rounded-full hover:bg-gray-100 transition-colors"
                    title="Sair"
                  >
                    <LogOut className="w-5 h-5 text-gray-600" />
                  </button>
                </div>
              </>
            ) : (
              <button
                onClick={() => redirectToLogin()}
                className="px-6 py-2 gradient-primary text-white rounded-full font-medium hover:opacity-90 transition-opacity shadow-lg"
              >
                Entrar
              </button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
