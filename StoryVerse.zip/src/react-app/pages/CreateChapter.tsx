import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Navbar from "@/react-app/components/Navbar";
import { Book } from "@/shared/types";
import { Loader2, ArrowLeft } from "lucide-react";

export default function CreateChapter() {
  const { bookId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [book, setBook] = useState<Book | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    chapter_number: 1,
  });

  useEffect(() => {
    if (bookId) {
      fetchBook();
    }
  }, [bookId]);

  const fetchBook = async () => {
    try {
      const [bookRes, chaptersRes] = await Promise.all([
        fetch(`/api/books/${bookId}`),
        fetch(`/api/books/${bookId}/chapters`),
      ]);

      if (bookRes.ok) {
        const bookData = await bookRes.json();
        setBook(bookData);
      }

      if (chaptersRes.ok) {
        const chaptersData = await chaptersRes.json();
        const nextNumber = chaptersData.length + 1;
        setFormData((prev) => ({ ...prev, chapter_number: nextNumber }));
      }
    } catch (error) {
      console.error("Failed to fetch book:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !bookId) return;

    setSaving(true);

    try {
      const res = await fetch("/api/chapters", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          book_id: parseInt(bookId),
          ...formData,
        }),
      });

      if (res.ok) {
        const chapter = await res.json();
        navigate(`/chapters/${chapter.id}/edit`);
      }
    } catch (error) {
      console.error("Failed to create chapter:", error);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
        <Navbar />
        <div className="flex justify-center items-center py-20">
          <Loader2 className="w-10 h-10 animate-spin text-purple-600" />
        </div>
      </div>
    );
  }

  if (!book) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
        <Navbar />
        <div className="max-w-4xl mx-auto px-4 py-20 text-center">
          <p className="text-gray-500 text-lg">Livro não encontrado</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
      <Navbar />

      <main className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={() => navigate(`/books/${bookId}/edit`)}
          className="inline-flex items-center space-x-2 text-purple-600 hover:text-purple-700 mb-8 font-medium"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar</span>
        </button>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Criar Novo Capítulo</h1>
          <p className="text-gray-600 mb-8">Livro: {book.title}</p>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Número do Capítulo *
              </label>
              <input
                type="number"
                value={formData.chapter_number}
                onChange={(e) =>
                  setFormData({ ...formData, chapter_number: parseInt(e.target.value) })
                }
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                required
                min={1}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Título do Capítulo *
              </label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                required
                maxLength={200}
                placeholder="Ex: O Início da Jornada"
              />
            </div>

            <button
              type="submit"
              disabled={saving || !formData.title}
              className="w-full px-6 py-3 gradient-primary text-white rounded-lg font-medium hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center space-x-2"
            >
              {saving ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Criando...</span>
                </>
              ) : (
                <span>Criar Capítulo</span>
              )}
            </button>
          </form>
        </div>
      </main>
    </div>
  );
}
