import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router";
import Navbar from "@/react-app/components/Navbar";
import { Book, Chapter } from "@/shared/types";
import { Loader2, ArrowLeft, Plus, Edit, Trash2 } from "lucide-react";

export default function EditBook() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [book, setBook] = useState<Book | null>(null);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    genre: "",
    cover_image_url: "",
  });

  useEffect(() => {
    if (id) {
      fetchBookAndChapters();
    }
  }, [id]);

  const fetchBookAndChapters = async () => {
    try {
      const [bookRes, chaptersRes] = await Promise.all([
        fetch(`/api/books/${id}`),
        fetch(`/api/books/${id}/chapters`),
      ]);

      if (bookRes.ok) {
        const bookData = await bookRes.json();
        setBook(bookData);
        setFormData({
          title: bookData.title,
          description: bookData.description || "",
          genre: bookData.genre || "",
          cover_image_url: bookData.cover_image_url || "",
        });
      }

      if (chaptersRes.ok) {
        const chaptersData = await chaptersRes.json();
        setChapters(chaptersData);
      }
    } catch (error) {
      console.error("Failed to fetch book:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    try {
      const res = await fetch(`/api/books/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (res.ok) {
        const updated = await res.json();
        setBook(updated);
      }
    } catch (error) {
      console.error("Failed to update book:", error);
    } finally {
      setSaving(false);
    }
  };

  const deleteChapter = async (chapterId: number) => {
    if (!confirm("Tem certeza que deseja excluir este capítulo?")) return;

    try {
      const res = await fetch(`/api/chapters/${chapterId}`, { method: "DELETE" });
      if (res.ok) {
        setChapters(chapters.filter((c) => c.id !== chapterId));
      }
    } catch (error) {
      console.error("Failed to delete chapter:", error);
    }
  };

  const togglePublishChapter = async (chapter: Chapter) => {
    if (chapter.is_published) {
      alert("Capítulo já está publicado");
      return;
    }

    try {
      const res = await fetch(`/api/chapters/${chapter.id}/publish`, {
        method: "POST",
      });
      if (res.ok) {
        setChapters(
          chapters.map((c) => (c.id === chapter.id ? { ...c, is_published: 1 } : c))
        );
      }
    } catch (error) {
      console.error("Failed to publish chapter:", error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
        <Navbar />
        <div className="flex justify-center items-center py-20">
          <Loader2 className="w-10 h-10 animate-spin text-purple-600" />
        </div>
      </div>
    );
  }

  if (!book) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
        <Navbar />
        <div className="max-w-4xl mx-auto px-4 py-20 text-center">
          <p className="text-gray-500 text-lg">Livro não encontrado</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
      <Navbar />

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={() => navigate("/my-books")}
          className="inline-flex items-center space-x-2 text-purple-600 hover:text-purple-700 mb-8 font-medium"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar aos meus livros</span>
        </button>

        <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">Editar Livro</h1>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Título *
              </label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                required
                maxLength={200}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Descrição
              </label>
              <textarea
                value={formData.description}
                onChange={(e) =>
                  setFormData({ ...formData, description: e.target.value })
                }
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
                rows={4}
                maxLength={2000}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Gênero
              </label>
              <input
                type="text"
                value={formData.genre}
                onChange={(e) => setFormData({ ...formData, genre: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                maxLength={50}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                URL da Capa
              </label>
              <input
                type="url"
                value={formData.cover_image_url}
                onChange={(e) =>
                  setFormData({ ...formData, cover_image_url: e.target.value })
                }
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full px-6 py-3 gradient-primary text-white rounded-lg font-medium hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center space-x-2"
            >
              {saving ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Salvando...</span>
                </>
              ) : (
                <span>Salvar Alterações</span>
              )}
            </button>
          </form>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Capítulos</h2>
            <Link
              to={`/books/${book.id}/create-chapter`}
              className="flex items-center space-x-2 px-4 py-2 gradient-primary text-white rounded-lg font-medium hover:opacity-90 transition-opacity"
            >
              <Plus className="w-4 h-4" />
              <span>Novo Capítulo</span>
            </Link>
          </div>

          {chapters.length === 0 ? (
            <p className="text-gray-500 text-center py-8">Nenhum capítulo criado ainda</p>
          ) : (
            <div className="space-y-3">
              {chapters.map((chapter) => (
                <div
                  key={chapter.id}
                  className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:border-purple-400 transition-colors"
                >
                  <div className="flex-1">
                    <div className="flex items-center space-x-3">
                      <span className="text-sm text-purple-600 font-medium">
                        Cap. {chapter.chapter_number}
                      </span>
                      <span className="text-gray-900 font-semibold">
                        {chapter.title}
                      </span>
                      {!chapter.is_published && (
                        <span className="px-2 py-1 bg-yellow-100 text-yellow-700 text-xs font-bold rounded-full">
                          Rascunho
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    {!chapter.is_published && (
                      <button
                        onClick={() => togglePublishChapter(chapter)}
                        className="px-3 py-1 bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition-colors text-sm font-medium"
                      >
                        Publicar
                      </button>
                    )}
                    <Link
                      to={`/chapters/${chapter.id}/edit`}
                      className="p-2 hover:bg-purple-100 rounded-lg transition-colors"
                    >
                      <Edit className="w-4 h-4 text-purple-600" />
                    </Link>
                    <button
                      onClick={() => deleteChapter(chapter.id)}
                      className="p-2 hover:bg-red-100 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4 text-red-600" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
