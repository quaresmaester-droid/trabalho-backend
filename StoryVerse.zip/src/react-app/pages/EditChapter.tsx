import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router";
import Navbar from "@/react-app/components/Navbar";
import ContentBlockEditor from "@/react-app/components/ContentBlockEditor";
import { Chapter, ContentBlock } from "@/shared/types";
import { Loader2, ArrowLeft, Save } from "lucide-react";

export default function EditChapter() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [chapter, setChapter] = useState<Chapter | null>(null);
  const [blocks, setBlocks] = useState<ContentBlock[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    chapter_number: 1,
  });

  useEffect(() => {
    if (id) {
      fetchChapterAndBlocks();
    }
  }, [id]);

  const fetchChapterAndBlocks = async () => {
    try {
      const [chapterRes, blocksRes] = await Promise.all([
        fetch(`/api/chapters/${id}`),
        fetch(`/api/chapters/${id}/content-blocks`),
      ]);

      if (chapterRes.ok) {
        const chapterData = await chapterRes.json();
        setChapter(chapterData);
        setFormData({
          title: chapterData.title,
          chapter_number: chapterData.chapter_number,
        });
      }

      if (blocksRes.ok) {
        const blocksData = await blocksRes.json();
        setBlocks(blocksData);
      }
    } catch (error) {
      console.error("Failed to fetch chapter:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateChapter = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    try {
      const res = await fetch(`/api/chapters/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (res.ok) {
        const updated = await res.json();
        setChapter(updated);
      }
    } catch (error) {
      console.error("Failed to update chapter:", error);
    } finally {
      setSaving(false);
    }
  };

  const handleBlocksUpdate = (updatedBlocks: ContentBlock[]) => {
    setBlocks(updatedBlocks);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
        <Navbar />
        <div className="flex justify-center items-center py-20">
          <Loader2 className="w-10 h-10 animate-spin text-purple-600" />
        </div>
      </div>
    );
  }

  if (!chapter) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
        <Navbar />
        <div className="max-w-4xl mx-auto px-4 py-20 text-center">
          <p className="text-gray-500 text-lg">Capítulo não encontrado</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
      <Navbar />

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={() => navigate(`/books/${chapter.book_id}/edit`)}
          className="inline-flex items-center space-x-2 text-purple-600 hover:text-purple-700 mb-8 font-medium"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar ao livro</span>
        </button>

        <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">Editar Capítulo</h1>

          <form onSubmit={handleUpdateChapter} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Número do Capítulo *
                </label>
                <input
                  type="number"
                  value={formData.chapter_number}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      chapter_number: parseInt(e.target.value),
                    })
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  required
                  min={1}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Título do Capítulo *
                </label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) =>
                    setFormData({ ...formData, title: e.target.value })
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  required
                  maxLength={200}
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full px-6 py-3 gradient-primary text-white rounded-lg font-medium hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center space-x-2"
            >
              {saving ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Salvando...</span>
                </>
              ) : (
                <>
                  <Save className="w-5 h-5" />
                  <span>Salvar Info do Capítulo</span>
                </>
              )}
            </button>
          </form>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Conteúdo do Capítulo</h2>
          <ContentBlockEditor
            chapterId={chapter.id}
            blocks={blocks}
            onBlocksUpdate={handleBlocksUpdate}
          />
        </div>
      </main>
    </div>
  );
}
