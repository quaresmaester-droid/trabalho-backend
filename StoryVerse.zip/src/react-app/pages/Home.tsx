import { useEffect, useState } from "react";
import Navbar from "@/react-app/components/Navbar";
import BookCard from "@/react-app/components/BookCard";
import { Book } from "@/shared/types";
import { Loader2 } from "lucide-react";

export default function Home() {
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      const res = await fetch("/api/books");
      const data = await res.json();
      setBooks(data);
    } catch (error) {
      console.error("Failed to fetch books:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
      <Navbar />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold mb-4 gradient-primary text-gradient">
            Descubra Histórias Incríveis
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Uma plataforma para autores compartilharem suas histórias, contos e fanfics com o mundo
          </p>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-20">
            <Loader2 className="w-10 h-10 animate-spin text-purple-600" />
          </div>
        ) : books.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-gray-500 text-lg">
              Nenhum livro publicado ainda. Seja o primeiro a compartilhar sua história!
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {books.map((book) => (
              <BookCard key={book.id} book={book} />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
