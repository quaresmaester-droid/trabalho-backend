import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import Navbar from "@/react-app/components/Navbar";
import { Book } from "@/shared/types";
import { Loader2, Plus, BookOpen, Edit, Trash2 } from "lucide-react";

export default function MyBooks() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isPending && !user) {
      navigate("/");
    }
  }, [user, isPending, navigate]);

  useEffect(() => {
    if (user) {
      fetchMyBooks();
    }
  }, [user]);

  const fetchMyBooks = async () => {
    try {
      const res = await fetch("/api/my-books");
      if (res.ok) {
        const data = await res.json();
        setBooks(data);
      }
    } catch (error) {
      console.error("Failed to fetch books:", error);
    } finally {
      setLoading(false);
    }
  };

  const deleteBook = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir este livro?")) return;

    try {
      const res = await fetch(`/api/books/${id}`, { method: "DELETE" });
      if (res.ok) {
        setBooks(books.filter((b) => b.id !== id));
      }
    } catch (error) {
      console.error("Failed to delete book:", error);
    }
  };

  const togglePublish = async (book: Book) => {
    if (book.is_published) {
      alert("Livro já está publicado");
      return;
    }

    try {
      const res = await fetch(`/api/books/${book.id}/publish`, { method: "POST" });
      if (res.ok) {
        setBooks(books.map((b) => (b.id === book.id ? { ...b, is_published: 1 } : b)));
      }
    } catch (error) {
      console.error("Failed to publish book:", error);
    }
  };

  if (isPending || loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
        <Navbar />
        <div className="flex justify-center items-center py-20">
          <Loader2 className="w-10 h-10 animate-spin text-purple-600" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
      <Navbar />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900">Meus Livros</h1>
          <Link
            to="/create-book"
            className="flex items-center space-x-2 px-6 py-3 gradient-primary text-white rounded-full font-medium hover:opacity-90 transition-opacity shadow-lg"
          >
            <Plus className="w-5 h-5" />
            <span>Novo Livro</span>
          </Link>
        </div>

        {books.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-2xl shadow-xl">
            <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 text-lg mb-6">
              Você ainda não criou nenhum livro
            </p>
            <Link
              to="/create-book"
              className="inline-flex items-center space-x-2 px-6 py-3 gradient-primary text-white rounded-full font-medium hover:opacity-90 transition-opacity"
            >
              <Plus className="w-5 h-5" />
              <span>Criar Primeiro Livro</span>
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {books.map((book) => (
              <div
                key={book.id}
                className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-shadow"
              >
                <div className="aspect-[3/4] bg-gradient-to-br from-purple-400 to-pink-400 relative">
                  {book.cover_image_url ? (
                    <img
                      src={book.cover_image_url}
                      alt={book.title}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <BookOpen className="w-16 h-16 text-white opacity-30" />
                    </div>
                  )}
                  {!book.is_published && (
                    <div className="absolute top-3 right-3">
                      <span className="px-3 py-1 bg-yellow-500 text-white text-xs font-bold rounded-full">
                        Rascunho
                      </span>
                    </div>
                  )}
                </div>

                <div className="p-4">
                  <h3 className="font-bold text-lg text-gray-900 mb-2 line-clamp-1">
                    {book.title}
                  </h3>

                  <div className="flex flex-wrap gap-2 mb-4">
                    <Link
                      to={`/books/${book.id}/edit`}
                      className="flex-1 flex items-center justify-center space-x-1 px-3 py-2 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200 transition-colors text-sm font-medium"
                    >
                      <Edit className="w-4 h-4" />
                      <span>Editar</span>
                    </Link>
                    <button
                      onClick={() => deleteBook(book.id)}
                      className="flex items-center justify-center space-x-1 px-3 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors text-sm font-medium"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {!book.is_published && (
                    <button
                      onClick={() => togglePublish(book)}
                      className="w-full px-4 py-2 gradient-primary text-white rounded-lg font-medium hover:opacity-90 transition-opacity text-sm"
                    >
                      Publicar
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
