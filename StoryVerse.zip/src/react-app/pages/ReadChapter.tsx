import { useEffect, useState, useRef } from "react";
import { useParams, Link } from "react-router";
import Navbar from "@/react-app/components/Navbar";
import { Chapter, ContentBlock } from "@/shared/types";
import { Loader2, ArrowLeft, Play, Pause } from "lucide-react";

export default function ReadChapter() {
  const { bookId, chapterId } = useParams();
  const [chapter, setChapter] = useState<Chapter | null>(null);
  const [blocks, setBlocks] = useState<ContentBlock[]>([]);
  const [loading, setLoading] = useState(true);
  const [playingMedia, setPlayingMedia] = useState<number | null>(null);
  const mediaRefs = useRef<{ [key: number]: HTMLVideoElement | HTMLAudioElement }>({});

  useEffect(() => {
    if (chapterId) {
      fetchChapterAndBlocks();
    }
  }, [chapterId]);

  const fetchChapterAndBlocks = async () => {
    try {
      const [chapterRes, blocksRes] = await Promise.all([
        fetch(`/api/chapters/${chapterId}`),
        fetch(`/api/chapters/${chapterId}/content-blocks`),
      ]);

      if (chapterRes.ok) {
        const chapterData = await chapterRes.json();
        setChapter(chapterData);
      }

      if (blocksRes.ok) {
        const blocksData = await blocksRes.json();
        setBlocks(blocksData);
      }
    } catch (error) {
      console.error("Failed to fetch chapter:", error);
    } finally {
      setLoading(false);
    }
  };

  const getEmbedUrl = (url: string, source?: string) => {
    if (source === "youtube") {
      const videoId = url.split("v=")[1]?.split("&")[0] || url.split("/").pop();
      return `https://www.youtube.com/embed/${videoId}`;
    }
    if (source === "dailymotion") {
      const videoId = url.split("/video/")[1]?.split("_")[0];
      return `https://www.dailymotion.com/embed/video/${videoId}`;
    }
    return url;
  };

  const toggleMedia = (blockId: number) => {
    const media = mediaRefs.current[blockId];
    if (!media) return;

    if (playingMedia === blockId) {
      media.pause();
      setPlayingMedia(null);
    } else {
      // Pause other media
      Object.values(mediaRefs.current).forEach((m) => m.pause());
      media.play();
      setPlayingMedia(blockId);
    }
  };

  const renderMediaBlock = (block: ContentBlock) => {
    if (!block.media_type || !block.media_url) return null;

    if (block.media_type === "video" && block.media_source !== "upload") {
      return (
        <div className="my-6">
          <div className="relative aspect-video rounded-lg overflow-hidden shadow-lg">
            <iframe
              src={getEmbedUrl(block.media_url, block.media_source || undefined)}
              className="absolute inset-0 w-full h-full"
              allowFullScreen
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            />
          </div>
        </div>
      );
    }

    if (block.media_type === "image" || block.media_type === "gif") {
      return (
        <div className="my-6">
          <img
            src={block.media_url}
            alt="Conteúdo visual"
            className="rounded-lg shadow-lg max-w-full mx-auto"
          />
        </div>
      );
    }

    if (block.media_type === "video" && block.media_source === "upload") {
      return (
        <div className="my-6">
          <div className="relative aspect-video rounded-lg overflow-hidden shadow-lg bg-black">
            <video
              ref={(el) => {
                if (el) mediaRefs.current[block.id] = el;
              }}
              src={block.media_url}
              className="absolute inset-0 w-full h-full"
              controls
              onPlay={() => setPlayingMedia(block.id)}
              onPause={() => setPlayingMedia(null)}
            />
          </div>
        </div>
      );
    }

    if (block.media_type === "audio") {
      return (
        <div className="my-6">
          <div className="bg-gradient-to-r from-purple-100 to-pink-100 rounded-lg p-6 shadow-lg">
            <audio
              ref={(el) => {
                if (el) mediaRefs.current[block.id] = el;
              }}
              src={block.media_url}
              className="w-full mb-3"
              onPlay={() => setPlayingMedia(block.id)}
              onPause={() => setPlayingMedia(null)}
            />
            <button
              onClick={() => toggleMedia(block.id)}
              className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-full hover:bg-purple-700 transition-colors mx-auto"
            >
              {playingMedia === block.id ? (
                <>
                  <Pause className="w-4 h-4" />
                  <span>Pausar</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  <span>Reproduzir Áudio</span>
                </>
              )}
            </button>
          </div>
        </div>
      );
    }

    return null;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
        <Navbar />
        <div className="flex justify-center items-center py-20">
          <Loader2 className="w-10 h-10 animate-spin text-purple-600" />
        </div>
      </div>
    );
  }

  if (!chapter) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
        <Navbar />
        <div className="max-w-4xl mx-auto px-4 py-20 text-center">
          <p className="text-gray-500 text-lg">Capítulo não encontrado</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
      <Navbar />

      <main className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Link
          to={`/books/${bookId}`}
          className="inline-flex items-center space-x-2 text-purple-600 hover:text-purple-700 mb-8 font-medium"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar ao livro</span>
        </Link>

        <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12">
          <div className="mb-8 pb-8 border-b border-gray-200">
            <span className="text-sm text-purple-600 font-medium">
              Capítulo {chapter.chapter_number}
            </span>
            <h1 className="text-4xl font-bold text-gray-900 mt-2">{chapter.title}</h1>
          </div>

          <div className="font-reading text-gray-800 leading-relaxed">
            {blocks.length === 0 ? (
              <p className="text-gray-500 text-center py-8">Este capítulo está vazio</p>
            ) : (
              blocks.map((block) => (
                <div key={block.id} className="mb-6">
                  {block.text_content && (
                    <p className="text-lg mb-4 whitespace-pre-wrap">{block.text_content}</p>
                  )}
                  {renderMediaBlock(block)}
                </div>
              ))
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
