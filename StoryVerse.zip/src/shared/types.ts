import z from "zod";

// Book schemas
export const BookSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  title: z.string(),
  description: z.string().nullable(),
  cover_image_url: z.string().nullable(),
  genre: z.string().nullable(),
  language: z.string(),
  is_published: z.number().int(),
  view_count: z.number().int(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateBookSchema = z.object({
  title: z.string().min(1, "Título é obrigatório").max(200),
  description: z.string().max(2000).optional(),
  cover_image_url: z.string().url().optional(),
  genre: z.string().max(50).optional(),
  language: z.string().default("pt"),
});

export const UpdateBookSchema = CreateBookSchema.partial();

// Chapter schemas
export const ChapterSchema = z.object({
  id: z.number(),
  book_id: z.number(),
  title: z.string(),
  chapter_number: z.number().int(),
  is_published: z.number().int(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateChapterSchema = z.object({
  book_id: z.number(),
  title: z.string().min(1, "Título do capítulo é obrigatório").max(200),
  chapter_number: z.number().int().min(1),
});

export const UpdateChapterSchema = z.object({
  title: z.string().min(1).max(200).optional(),
  chapter_number: z.number().int().min(1).optional(),
});

// Content block schemas
export const ContentBlockSchema = z.object({
  id: z.number(),
  chapter_id: z.number(),
  block_order: z.number().int(),
  text_content: z.string().nullable(),
  media_type: z.string().nullable(),
  media_url: z.string().nullable(),
  media_source: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateContentBlockSchema = z.object({
  chapter_id: z.number(),
  block_order: z.number().int().min(0),
  text_content: z.string().optional(),
  media_type: z.enum(["image", "video", "audio", "gif"]).optional(),
  media_url: z.string().url().optional(),
  media_source: z.enum(["youtube", "dailymotion", "drive", "upload"]).optional(),
});

export const UpdateContentBlockSchema = CreateContentBlockSchema.partial().omit({ chapter_id: true });

// Types
export type Book = z.infer<typeof BookSchema>;
export type CreateBook = z.infer<typeof CreateBookSchema>;
export type UpdateBook = z.infer<typeof UpdateBookSchema>;

export type Chapter = z.infer<typeof ChapterSchema>;
export type CreateChapter = z.infer<typeof CreateChapterSchema>;
export type UpdateChapter = z.infer<typeof UpdateChapterSchema>;

export type ContentBlock = z.infer<typeof ContentBlockSchema>;
export type CreateContentBlock = z.infer<typeof CreateContentBlockSchema>;
export type UpdateContentBlock = z.infer<typeof UpdateContentBlockSchema>;
