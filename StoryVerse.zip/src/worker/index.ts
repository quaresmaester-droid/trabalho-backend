import { Hono } from "hono";
import { getCookie, setCookie } from "hono/cookie";
import {
  authMiddleware,
  deleteSession,
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";
import {
  BookSchema,
  ChapterSchema,
  ContentBlockSchema,
  CreateBookSchema,
  CreateChapterSchema,
  CreateContentBlockSchema,
  UpdateBookSchema,
  UpdateChapterSchema,
  UpdateContentBlockSchema,
} from "@/shared/types";

const app = new Hono<{ Bindings: Env }>();

// Auth routes
app.get("/api/oauth/google/redirect_url", async (c) => {
  const redirectUrl = await getOAuthRedirectUrl("google", {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  const sessionToken = await exchangeCodeForSessionToken(body.code, {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60,
  });

  return c.json({ success: true }, 200);
});

app.get("/api/users/me", authMiddleware, async (c) => {
  return c.json(c.get("user"));
});

app.get("/api/logout", async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === "string") {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, "", {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// Books routes
app.get("/api/books", async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM books WHERE is_published = 1 ORDER BY created_at DESC LIMIT 50"
  ).all();

  return c.json(results.map((r) => BookSchema.parse(r)));
});

app.get("/api/books/:id", async (c) => {
  const id = c.req.param("id");
  const book = await c.env.DB.prepare("SELECT * FROM books WHERE id = ?")
    .bind(id)
    .first();

  if (!book) {
    return c.json({ error: "Book not found" }, 404);
  }

  // Increment view count
  await c.env.DB.prepare("UPDATE books SET view_count = view_count + 1 WHERE id = ?")
    .bind(id)
    .run();

  return c.json(BookSchema.parse(book));
});

app.get("/api/my-books", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM books WHERE user_id = ? ORDER BY created_at DESC"
  )
    .bind(user.id)
    .all();

  return c.json(results.map((r) => BookSchema.parse(r)));
});

app.post("/api/books", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();
  const data = CreateBookSchema.parse(body);

  const result = await c.env.DB.prepare(
    `INSERT INTO books (user_id, title, description, cover_image_url, genre, language, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`
  )
    .bind(
      user.id,
      data.title,
      data.description || null,
      data.cover_image_url || null,
      data.genre || null,
      data.language || "pt"
    )
    .run();

  const book = await c.env.DB.prepare("SELECT * FROM books WHERE id = ?")
    .bind(result.meta.last_row_id)
    .first();

  return c.json(BookSchema.parse(book), 201);
});

app.patch("/api/books/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const body = await c.req.json();
  const data = UpdateBookSchema.parse(body);

  const book = await c.env.DB.prepare("SELECT * FROM books WHERE id = ?")
    .bind(id)
    .first();

  if (!book) {
    return c.json({ error: "Book not found" }, 404);
  }

  if ((book as any).user_id !== user.id) {
    return c.json({ error: "Forbidden" }, 403);
  }

  const updates: string[] = [];
  const values: any[] = [];

  if (data.title !== undefined) {
    updates.push("title = ?");
    values.push(data.title);
  }
  if (data.description !== undefined) {
    updates.push("description = ?");
    values.push(data.description);
  }
  if (data.cover_image_url !== undefined) {
    updates.push("cover_image_url = ?");
    values.push(data.cover_image_url);
  }
  if (data.genre !== undefined) {
    updates.push("genre = ?");
    values.push(data.genre);
  }
  if (data.language !== undefined) {
    updates.push("language = ?");
    values.push(data.language);
  }

  if (updates.length > 0) {
    updates.push("updated_at = CURRENT_TIMESTAMP");
    values.push(id);

    await c.env.DB.prepare(
      `UPDATE books SET ${updates.join(", ")} WHERE id = ?`
    )
      .bind(...values)
      .run();
  }

  const updated = await c.env.DB.prepare("SELECT * FROM books WHERE id = ?")
    .bind(id)
    .first();

  return c.json(BookSchema.parse(updated));
});

app.post("/api/books/:id/publish", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");

  const book = await c.env.DB.prepare("SELECT * FROM books WHERE id = ?")
    .bind(id)
    .first();

  if (!book) {
    return c.json({ error: "Book not found" }, 404);
  }

  if ((book as any).user_id !== user.id) {
    return c.json({ error: "Forbidden" }, 403);
  }

  await c.env.DB.prepare(
    "UPDATE books SET is_published = 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  )
    .bind(id)
    .run();

  return c.json({ success: true });
});

app.delete("/api/books/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");

  const book = await c.env.DB.prepare("SELECT * FROM books WHERE id = ?")
    .bind(id)
    .first();

  if (!book) {
    return c.json({ error: "Book not found" }, 404);
  }

  if ((book as any).user_id !== user.id) {
    return c.json({ error: "Forbidden" }, 403);
  }

  await c.env.DB.prepare("DELETE FROM books WHERE id = ?").bind(id).run();

  return c.json({ success: true });
});

// Chapters routes
app.get("/api/books/:bookId/chapters", async (c) => {
  const bookId = c.req.param("bookId");
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM chapters WHERE book_id = ? ORDER BY chapter_number ASC"
  )
    .bind(bookId)
    .all();

  return c.json(results.map((r) => ChapterSchema.parse(r)));
});

app.get("/api/chapters/:id", async (c) => {
  const id = c.req.param("id");
  const chapter = await c.env.DB.prepare("SELECT * FROM chapters WHERE id = ?")
    .bind(id)
    .first();

  if (!chapter) {
    return c.json({ error: "Chapter not found" }, 404);
  }

  return c.json(ChapterSchema.parse(chapter));
});

app.post("/api/chapters", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();
  const data = CreateChapterSchema.parse(body);

  const book = await c.env.DB.prepare("SELECT * FROM books WHERE id = ?")
    .bind(data.book_id)
    .first();

  if (!book) {
    return c.json({ error: "Book not found" }, 404);
  }

  if ((book as any).user_id !== user.id) {
    return c.json({ error: "Forbidden" }, 403);
  }

  const result = await c.env.DB.prepare(
    `INSERT INTO chapters (book_id, title, chapter_number, created_at, updated_at)
     VALUES (?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`
  )
    .bind(data.book_id, data.title, data.chapter_number)
    .run();

  const chapter = await c.env.DB.prepare("SELECT * FROM chapters WHERE id = ?")
    .bind(result.meta.last_row_id)
    .first();

  return c.json(ChapterSchema.parse(chapter), 201);
});

app.patch("/api/chapters/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const body = await c.req.json();
  const data = UpdateChapterSchema.parse(body);

  const chapter = await c.env.DB.prepare(
    `SELECT chapters.*, books.user_id 
     FROM chapters 
     JOIN books ON chapters.book_id = books.id 
     WHERE chapters.id = ?`
  )
    .bind(id)
    .first();

  if (!chapter) {
    return c.json({ error: "Chapter not found" }, 404);
  }

  if ((chapter as any).user_id !== user.id) {
    return c.json({ error: "Forbidden" }, 403);
  }

  const updates: string[] = [];
  const values: any[] = [];

  if (data.title !== undefined) {
    updates.push("title = ?");
    values.push(data.title);
  }
  if (data.chapter_number !== undefined) {
    updates.push("chapter_number = ?");
    values.push(data.chapter_number);
  }

  if (updates.length > 0) {
    updates.push("updated_at = CURRENT_TIMESTAMP");
    values.push(id);

    await c.env.DB.prepare(
      `UPDATE chapters SET ${updates.join(", ")} WHERE id = ?`
    )
      .bind(...values)
      .run();
  }

  const updated = await c.env.DB.prepare("SELECT * FROM chapters WHERE id = ?")
    .bind(id)
    .first();

  return c.json(ChapterSchema.parse(updated));
});

app.post("/api/chapters/:id/publish", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");

  const chapter = await c.env.DB.prepare(
    `SELECT chapters.*, books.user_id 
     FROM chapters 
     JOIN books ON chapters.book_id = books.id 
     WHERE chapters.id = ?`
  )
    .bind(id)
    .first();

  if (!chapter) {
    return c.json({ error: "Chapter not found" }, 404);
  }

  if ((chapter as any).user_id !== user.id) {
    return c.json({ error: "Forbidden" }, 403);
  }

  await c.env.DB.prepare(
    "UPDATE chapters SET is_published = 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  )
    .bind(id)
    .run();

  return c.json({ success: true });
});

app.delete("/api/chapters/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");

  const chapter = await c.env.DB.prepare(
    `SELECT chapters.*, books.user_id 
     FROM chapters 
     JOIN books ON chapters.book_id = books.id 
     WHERE chapters.id = ?`
  )
    .bind(id)
    .first();

  if (!chapter) {
    return c.json({ error: "Chapter not found" }, 404);
  }

  if ((chapter as any).user_id !== user.id) {
    return c.json({ error: "Forbidden" }, 403);
  }

  await c.env.DB.prepare("DELETE FROM chapters WHERE id = ?").bind(id).run();

  return c.json({ success: true });
});

// Content blocks routes
app.get("/api/chapters/:chapterId/content-blocks", async (c) => {
  const chapterId = c.req.param("chapterId");
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM content_blocks WHERE chapter_id = ? ORDER BY block_order ASC"
  )
    .bind(chapterId)
    .all();

  return c.json(results.map((r) => ContentBlockSchema.parse(r)));
});

app.post("/api/content-blocks", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();
  const data = CreateContentBlockSchema.parse(body);

  const chapter = await c.env.DB.prepare(
    `SELECT chapters.*, books.user_id 
     FROM chapters 
     JOIN books ON chapters.book_id = books.id 
     WHERE chapters.id = ?`
  )
    .bind(data.chapter_id)
    .first();

  if (!chapter) {
    return c.json({ error: "Chapter not found" }, 404);
  }

  if ((chapter as any).user_id !== user.id) {
    return c.json({ error: "Forbidden" }, 403);
  }

  const result = await c.env.DB.prepare(
    `INSERT INTO content_blocks (chapter_id, block_order, text_content, media_type, media_url, media_source, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`
  )
    .bind(
      data.chapter_id,
      data.block_order,
      data.text_content || null,
      data.media_type || null,
      data.media_url || null,
      data.media_source || null
    )
    .run();

  const block = await c.env.DB.prepare(
    "SELECT * FROM content_blocks WHERE id = ?"
  )
    .bind(result.meta.last_row_id)
    .first();

  return c.json(ContentBlockSchema.parse(block), 201);
});

app.patch("/api/content-blocks/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const body = await c.req.json();
  const data = UpdateContentBlockSchema.parse(body);

  const block = await c.env.DB.prepare(
    `SELECT content_blocks.*, books.user_id 
     FROM content_blocks 
     JOIN chapters ON content_blocks.chapter_id = chapters.id
     JOIN books ON chapters.book_id = books.id 
     WHERE content_blocks.id = ?`
  )
    .bind(id)
    .first();

  if (!block) {
    return c.json({ error: "Content block not found" }, 404);
  }

  if ((block as any).user_id !== user.id) {
    return c.json({ error: "Forbidden" }, 403);
  }

  const updates: string[] = [];
  const values: any[] = [];

  if (data.block_order !== undefined) {
    updates.push("block_order = ?");
    values.push(data.block_order);
  }
  if (data.text_content !== undefined) {
    updates.push("text_content = ?");
    values.push(data.text_content);
  }
  if (data.media_type !== undefined) {
    updates.push("media_type = ?");
    values.push(data.media_type);
  }
  if (data.media_url !== undefined) {
    updates.push("media_url = ?");
    values.push(data.media_url);
  }
  if (data.media_source !== undefined) {
    updates.push("media_source = ?");
    values.push(data.media_source);
  }

  if (updates.length > 0) {
    updates.push("updated_at = CURRENT_TIMESTAMP");
    values.push(id);

    await c.env.DB.prepare(
      `UPDATE content_blocks SET ${updates.join(", ")} WHERE id = ?`
    )
      .bind(...values)
      .run();
  }

  const updated = await c.env.DB.prepare(
    "SELECT * FROM content_blocks WHERE id = ?"
  )
    .bind(id)
    .first();

  return c.json(ContentBlockSchema.parse(updated));
});

app.delete("/api/content-blocks/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");

  const block = await c.env.DB.prepare(
    `SELECT content_blocks.*, books.user_id 
     FROM content_blocks 
     JOIN chapters ON content_blocks.chapter_id = chapters.id
     JOIN books ON chapters.book_id = books.id 
     WHERE content_blocks.id = ?`
  )
    .bind(id)
    .first();

  if (!block) {
    return c.json({ error: "Content block not found" }, 404);
  }

  if ((block as any).user_id !== user.id) {
    return c.json({ error: "Forbidden" }, 403);
  }

  await c.env.DB.prepare("DELETE FROM content_blocks WHERE id = ?")
    .bind(id)
    .run();

  return c.json({ success: true });
});

// File upload route
app.post("/api/upload", authMiddleware, async (c) => {
  const formData = await c.req.formData();
  const file = formData.get("file") as File;

  if (!file) {
    return c.json({ error: "No file provided" }, 400);
  }

  const user = c.get("user")!;
  const timestamp = Date.now();
  const filename = `${user.id}/${timestamp}-${file.name}`;

  await c.env.R2_BUCKET.put(filename, file.stream(), {
    httpMetadata: {
      contentType: file.type,
    },
  });

  return c.json({ url: `/api/files/${encodeURIComponent(filename)}` }, 201);
});

app.get("/api/files/:filename", async (c) => {
  const filename = decodeURIComponent(c.req.param("filename"));
  const object = await c.env.R2_BUCKET.get(filename);

  if (!object) {
    return c.json({ error: "File not found" }, 404);
  }

  const headers = new Headers();
  object.writeHttpMetadata(headers);
  headers.set("etag", object.httpEtag);

  return c.body(object.body, { headers });
});

export default app;
